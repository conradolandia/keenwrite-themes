# Handrit

A theme suitable for exporting manuscripts. Aspects of this theme include:

* Double-spaced lines
* Courier font (TeX Gyre Cursor)
* Plain hyperlinks
* Single hash for scene separators
* Author and title in upper-right corner
* The word "END" is centered after the last paragraph

